export interface User
{
  id:string;
  firstName : string;
  lastName:string;
  email:string;
  gender:string;
  hobbies: string;
  dateOfBirth:any;
  ImageUpload:string;

}

